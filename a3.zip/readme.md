# Game Name : Countdown Game
- based on IT crowd's "Street Countdown Game" where a player picks letters with a mix of consonants and vowels
- player who has the longest word gets to say it and wins
- if the word is found on the anagram api, then the player will get points the score system is the number of letters multiplied by 10

- I got the the anagram api here: http://www.anagramica.com/api
- live version, may not be up for a bit: http://countdowngame.herokuapp.com


bugs:
- when both users chose the same number of char length the game freezes
